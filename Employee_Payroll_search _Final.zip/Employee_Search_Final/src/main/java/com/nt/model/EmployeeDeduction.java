package com.nt.model;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "employee_Deduction_details")
public class EmployeeDeduction {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Deduction_name")
    private String deductionName;

    @Column(name = "Deduction_Value")
    private Double deductionValue;

    @Column(name = "Calculation_Type")
    private String calculationType;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date")
    private Date createdDate;
    
    @Column(name = "Created_By")
    private String createdBy;
    

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "Update_date")
    private Date updatedDate;
    
    @Column(name = "Updated_By")
    private String updatedBy;

    @Column(name = "status")
    private int status = 1;
    
    @ManyToOne
    @JoinColumn(name = "employee_id")
    private EmployeeMaster employeeMaster;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDeductionName() {
		return deductionName;
	}

	public void setDeductionName(String deductionName) {
		this.deductionName = deductionName;
	}

	public Double getDeductionValue() {
		return deductionValue;
	}

	public void setDeductionValue(Double deductionValue) {
		this.deductionValue = deductionValue;
	}

	public String getCalculationType() {
		return calculationType;
	}

	public void setCalculationType(String calculationType) {
		this.calculationType = calculationType;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public EmployeeMaster getEmployeeMaster() {
		return employeeMaster;
	}

	public void setEmployeeMaster(EmployeeMaster employeeMaster) {
		this.employeeMaster = employeeMaster;
	}
    
    
}
