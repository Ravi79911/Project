package com.nt.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "employee_master")
public class EmployeeMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "employee_code")
    private String employeeCode;

    @Column(name = "employee_name", nullable = false)
    private String employeeName;

    @Column(name = "employee_phoneno")
    private String employeePhoneNo;
    
    @Column(name = "employee_location")
    private String employeeLocation;
    
    @Column(name = "employee_department")
    private String employeeDepartMent;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date")
    private Date createdDate;
    
    @Column(name = "status", nullable = false)
    private int status = 1;
    
    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "basic_id")
    private EmployeeBasic basic;

    @OneToMany(mappedBy = "employeeMaster", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<EmployeeAllowance> allowances = new ArrayList<>();

    @OneToMany(mappedBy = "employeeMaster", cascade = CascadeType.ALL,fetch = FetchType.LAZY,  orphanRemoval = true)
    private List<EmployeeDeduction> deductions = new ArrayList<>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeePhoneNo() {
		return employeePhoneNo;
	}

	public void setEmployeePhoneNo(String employeePhoneNo) {
		this.employeePhoneNo = employeePhoneNo;
	}

	public String getEmployeeLocation() {
		return employeeLocation;
	}

	public void setEmployeeLocation(String employeeLocation) {
		this.employeeLocation = employeeLocation;
	}

	public String getEmployeeDepartMent() {
		return employeeDepartMent;
	}

	public void setEmployeeDepartMent(String employeeDepartMent) {
		this.employeeDepartMent = employeeDepartMent;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public EmployeeBasic getBasic() {
		return basic;
	}

	public void setBasic(EmployeeBasic basic) {
		this.basic = basic;
	}

	public List<EmployeeAllowance> getAllowances() {
		return allowances;
	}

	public void setAllowances(List<EmployeeAllowance> allowances) {
		this.allowances = allowances;
	}

	public List<EmployeeDeduction> getDeductions() {
		return deductions;
	}

	public void setDeductions(List<EmployeeDeduction> deductions) {
		this.deductions = deductions;
	}

	
    
    
   
	
}
