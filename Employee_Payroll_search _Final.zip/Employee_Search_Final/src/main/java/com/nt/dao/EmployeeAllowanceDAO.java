package com.nt.dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.mgmt.HibernateUtil;
import com.nt.model.EmployeeAllowance;




public class EmployeeAllowanceDAO {
	
	
	public void saveEmployeeAllowance(List<EmployeeAllowance> allowance) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            for (EmployeeAllowance allowances : allowance) {
                session.save(allowances);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    
 public EmployeeAllowance getAllowanceById(Long id) {
    	
        try (Session session = HibernateUtil.getSessionFactory().openSession()){
            return session.get(EmployeeAllowance.class, id);
        
        } catch (Exception e) {
            e.printStackTrace();
        } 
        return null;
    }

	  
	  public EmployeeAllowance updateAllowance(EmployeeAllowance employeeAllowance) {
	  Transaction tx = null;
	  
	  try (Session session=HibernateUtil.getSessionFactory().openSession()){ 
		  tx = session.beginTransaction(); 
	  		session.update(employeeAllowance);
	  		tx.commit();
	  		} catch (Exception e) { 
	  			if (tx != null) tx.rollback();
	  			e.printStackTrace();
	  			} 
	  return employeeAllowance;
	  }
	  
	  public List<EmployeeAllowance> getAllAllowance() {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        List<EmployeeAllowance> basics = session.createQuery("FROM EmployeeAllowance WHERE status = 1", EmployeeAllowance.class).list();
	        session.close();
	        return basics;
	    }
	 
}
