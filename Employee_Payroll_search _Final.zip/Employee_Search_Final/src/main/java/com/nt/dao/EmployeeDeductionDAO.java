package com.nt.dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.mgmt.HibernateUtil;
import com.nt.model.EmployeeDeduction;



public class EmployeeDeductionDAO {
	
	
	public void saveEmployeeDeduction(List<EmployeeDeduction> deduction) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            for (EmployeeDeduction deductions : deduction) {
                session.save(deductions);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    
 public EmployeeDeduction getDeductionById(Long id) {
    	
        try (Session session = HibernateUtil.getSessionFactory().openSession()){
            return session.get(EmployeeDeduction.class, id);
        
        } catch (Exception e) {
            e.printStackTrace();
        } 
        return null;
    }

	  
	  public EmployeeDeduction updateDeduction(EmployeeDeduction employeeDeduction) {
	  Transaction tx = null;
	  
	  try (Session session=HibernateUtil.getSessionFactory().openSession()){ 
		  tx = session.beginTransaction(); 
	  		session.update(employeeDeduction);
	  		tx.commit();
	  		} catch (Exception e) { 
	  			if (tx != null) tx.rollback();
	  			e.printStackTrace();
	  			} 
	  return employeeDeduction;
	  }
	  
	  public List<EmployeeDeduction> getAllDeduction() {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        List<EmployeeDeduction> basics = session.createQuery("FROM EmployeeDeduction WHERE status = 1", EmployeeDeduction.class).list();
	        session.close();
	        return basics;
	    }
	 
}
