package com.nt.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.dao.EmployeeAllowanceDAO;
import com.nt.dao.EmployeeBasicDAO;
import com.nt.dao.EmployeeDeductionDAO;
import com.nt.dao.EmployeeMasterDAO;
import com.nt.mgmt.HibernateUtil;
import com.nt.model.EmployeeAllowance;
import com.nt.model.EmployeeBasic;
import com.nt.model.EmployeeDeduction;
import com.nt.model.EmployeeMaster;




@WebServlet("/editEmployee")
public class EmployeeEditAllDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public EmployeeEditAllDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		if (idStr != null) {
		    long id = Long.parseLong(idStr);

		    EmployeeMasterDAO employeeMasterDAO = new EmployeeMasterDAO();
		    EmployeeMaster empMaster = employeeMasterDAO.getEmployeeById(id);

		    if (empMaster != null) {
		        EmployeeBasicDAO basicDAO = new EmployeeBasicDAO();
		        List<EmployeeBasic> basics = basicDAO.getAllBasics();

		        // Create a HashSet to store unique scale names
		        Set<String> uniqueScaleNames = new HashSet<>();
		        List<EmployeeBasic> uniqueBasics = new ArrayList<>();
		        for (EmployeeBasic basic : basics) {
		            if (uniqueScaleNames.add(basic.getScaleName())) {
		                uniqueBasics.add(basic);
		            }
		        }

		        EmployeeAllowanceDAO allowanceDAO = new EmployeeAllowanceDAO();
		        List<EmployeeAllowance> allowance = allowanceDAO.getAllAllowance();

		        // Create a HashSet to store unique allowance names
		        Set<String> uniqueAllowanceNames = new HashSet<>();
		        List<EmployeeAllowance> uniqueAllowance = new ArrayList<>();
		        for (EmployeeAllowance allowanceItem : allowance) {
		            if (uniqueAllowanceNames.add(allowanceItem.getAllowanceName())) {
		                uniqueAllowance.add(allowanceItem);
		            }
		        }

		        EmployeeDeductionDAO deductionDAO = new EmployeeDeductionDAO();
		        List<EmployeeDeduction> deduction = deductionDAO.getAllDeduction();

		        // Create a HashSet to store unique deduction names
		        Set<String> uniqueDeductionNames = new HashSet<>();
		        List<EmployeeDeduction> uniqueDeduction = new ArrayList<>();
		        for (EmployeeDeduction deductionItem : deduction) {
		            if (uniqueDeductionNames.add(deductionItem.getDeductionName())) {
		                uniqueDeduction.add(deductionItem);
		            }
		        }
		        
		        request.setAttribute("empMaster", empMaster);
		        request.setAttribute("basics", uniqueBasics);
		        request.setAttribute("allowance", uniqueAllowance);
		        request.setAttribute("deduction", uniqueDeduction);

		        request.getRequestDispatcher("editEmployee.jsp").forward(request, response);
		    }
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long id = Long.parseLong(request.getParameter("id"));
        String fullName = request.getParameter("fullName");
        String location = request.getParameter("location");
        String phone = request.getParameter("phone");
        String department = request.getParameter("department");

        // Retrieve selected values
        String scaleName = request.getParameter("scaleName");
        String scaleValue = request.getParameter("scaleValue");
        String scaleCalculationType = request.getParameter("scaleCalculationType");

        // Retrieve allowances
        List<String> allowanceNames = Arrays.asList(request.getParameterValues("allowanceName"));
        List<String> allowanceValues = Arrays.asList(request.getParameterValues("allowanceValue"));
        List<String> allowanceTypes = Arrays.asList(request.getParameterValues("allowanceCalculationType"));

        // Retrieve deductions
        List<String> deductionNames = Arrays.asList(request.getParameterValues("deductionName"));
        List<String> deductionValues = Arrays.asList(request.getParameterValues("deductionValue"));
        List<String> deductionTypes = Arrays.asList(request.getParameterValues("deductionCalculationType"));

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        try {
            EmployeeMaster empMaster = session.get(EmployeeMaster.class, id);
            empMaster.setEmployeeName(fullName);
            empMaster.setEmployeeLocation(location);
            empMaster.setEmployeePhoneNo(phone);
            empMaster.setEmployeeDepartMent(department);

            EmployeeBasic basic = new EmployeeBasic();
            basic.setScaleName(scaleName);
            basic.setScaleValue(Double.parseDouble(scaleValue));
            basic.setCalculationType(scaleCalculationType);
            session.saveOrUpdate(basic);
            empMaster.setBasic(basic);

            empMaster.getAllowances().clear();
            empMaster.getDeductions().clear();
            session.saveOrUpdate(empMaster);

            for (int i = 0; i < allowanceNames.size(); i++) {
                EmployeeAllowance allowance = new EmployeeAllowance();
                allowance.setAllowanceName(allowanceNames.get(i));
                allowance.setAllowanceValue(Double.parseDouble(allowanceValues.get(i)));
                allowance.setCalculationType(allowanceTypes.get(i));
                allowance.setEmployeeMaster(empMaster);
                session.saveOrUpdate(allowance);
                empMaster.getAllowances().add(allowance);
            }

            for (int i = 0; i < deductionNames.size(); i++) {
                EmployeeDeduction deduction = new EmployeeDeduction();
                deduction.setDeductionName(deductionNames.get(i));
                deduction.setDeductionValue(Double.parseDouble(deductionValues.get(i)));
                deduction.setCalculationType(deductionTypes.get(i));
                deduction.setEmployeeMaster(empMaster);
                session.saveOrUpdate(deduction);
                empMaster.getDeductions().add(deduction);
            }

            session.saveOrUpdate(empMaster);
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }

        response.sendRedirect("success.jsp");
    }
}
