package com.nt.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nt.dao.EmployeeAllowanceDAO;
import com.nt.model.EmployeeAllowance;




/**
 * Servlet implementation class EmployeeListServlet
 */
@WebServlet("/allowanceList")
public class AllowanceListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */	
    public AllowanceListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EmployeeAllowanceDAO allowanceDAO = new EmployeeAllowanceDAO();

        List<EmployeeAllowance> allowances = allowanceDAO.getAllAllowance();

        // Use a Map to filter duplicates based on allowanceName
        Map<String, EmployeeAllowance> uniqueAllowancesMap = new HashMap<>();
        for (EmployeeAllowance allowance : allowances) {
            if (!uniqueAllowancesMap.containsKey(allowance.getAllowanceName())) {
                uniqueAllowancesMap.put(allowance.getAllowanceName(), allowance);
            }
        }

        // Convert the Map values to a List
        List<EmployeeAllowance> uniqueAllowancesList = new ArrayList<>(uniqueAllowancesMap.values());

        request.setAttribute("allowances", uniqueAllowancesList);
        request.getRequestDispatcher("allowanceList.jsp").forward(request, response);
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
