package com.nt.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nt.dao.EmployeeDeductionDAO;
import com.nt.model.EmployeeDeduction;



/**
 * Servlet implementation class EmployeeListServlet
 */
@WebServlet("/deductionList")
public class DeductionListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */	
    public DeductionListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 EmployeeDeductionDAO deductionDAO = new EmployeeDeductionDAO();

	        List<EmployeeDeduction> deductions = deductionDAO.getAllDeduction();

	        // Use a Map to filter duplicates based on deductionName
	        Map<String, EmployeeDeduction> uniqueDeductionsMap = new HashMap<>();
	        for (EmployeeDeduction deduction : deductions) {
	            if (!uniqueDeductionsMap.containsKey(deduction.getDeductionName())) {
	                uniqueDeductionsMap.put(deduction.getDeductionName(), deduction);
	            }
	        }

	        // Convert the Map values to a List
	        List<EmployeeDeduction> uniqueDeductionsList = new ArrayList<>(uniqueDeductionsMap.values());

	        request.setAttribute("deductions", uniqueDeductionsList);
	        request.getRequestDispatcher("deductionList.jsp").forward(request, response);
	    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
