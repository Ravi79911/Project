package com.nt.web;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nt.dao.EmployeeBasicDAO;
import com.nt.model.EmployeeBasic;

/**
 * Servlet implementation class EmployeeDelete
 */
@WebServlet("/employeeBasicDelete")
public class EmployeeBasicDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeBasicDelete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		if(idStr != null) {
			long id = Integer.parseInt(idStr);
			
			EmployeeBasicDAO employeeBasicDao = new EmployeeBasicDAO();
			EmployeeBasic empBasic = employeeBasicDao.getBsicById(id);
			
			if(empBasic != null) {
				empBasic.setStatus(0);
				empBasic.setUpdatedDate(new Date());
				employeeBasicDao.updateBasic(empBasic);
				
				 response.sendRedirect("UpdateSuccessBasic.jsp");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
