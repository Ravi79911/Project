package com.nt.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nt.mgmt.HibernateUtil;
import com.nt.model.EmployeeAllowance;


/**
 * Servlet implementation class EmployeeBasicServlet
 */
@WebServlet("/allowanceRegister")
public class AllowanceRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AllowanceRegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 String[] allowanceNames = request.getParameterValues("allowanceName");
	        String[] allowanceValues = request.getParameterValues("allowanceValue");
	        String[] allowanceCalculationTypes = request.getParameterValues("allowanceCalculationType");

	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction tx = session.beginTransaction();

	        try {
	            List<EmployeeAllowance> allowanceList = new ArrayList<>();
	            for (int i = 0; i < allowanceNames.length; i++) {
	                EmployeeAllowance allowance = new EmployeeAllowance();
	                allowance.setAllowanceName(allowanceNames[i]);
	                allowance.setAllowanceValue(Double.parseDouble(allowanceValues[i]));
	                allowance.setCalculationType(allowanceCalculationTypes[i]);
	                allowance.setCreatedDate(new Date());
	                allowanceList.add(allowance);
	                session.save(allowance);
	            }
	            tx.commit();
	            response.sendRedirect("successAllowance.jsp");
	        } catch (Exception e) {
	            if (tx != null) tx.rollback();
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	    }

	    
	}
