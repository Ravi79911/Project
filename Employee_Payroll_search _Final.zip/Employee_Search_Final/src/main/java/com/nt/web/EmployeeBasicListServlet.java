package com.nt.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nt.dao.EmployeeBasicDAO;
import com.nt.model.EmployeeBasic;





/**
 * Servlet implementation class EmployeeListServlet
 */
@WebServlet("/employeeBasicList")
public class EmployeeBasicListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */	
    public EmployeeBasicListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
        EmployeeBasicDAO employeeBasicDAO = new EmployeeBasicDAO();

        List<EmployeeBasic> basics = employeeBasicDAO.getAllBasics();

        // Use a Map to filter duplicates based on scaleName
//        Map<String, EmployeeBasic> uniqueBasicsMap = new HashMap<>();
//        for (EmployeeBasic basic : basics) {
//            if (!uniqueBasicsMap.containsKey(basic.getScaleName())) {
//                uniqueBasicsMap.put(basic.getScaleName(), basic);
//            }
//        }
//
//        // Convert the Map values to a List
//        List<EmployeeBasic> uniqueBasicsList = new ArrayList<>(uniqueBasicsMap.values());

       // request.setAttribute("basics", uniqueBasicsList);
        request.setAttribute("basics", basics);
        request.getRequestDispatcher("employeeBasicList.jsp").forward(request, response);
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
