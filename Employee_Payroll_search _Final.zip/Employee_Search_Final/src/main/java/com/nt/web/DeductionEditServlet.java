package com.nt.web;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nt.dao.EmployeeDeductionDAO;
import com.nt.model.EmployeeDeduction;







/**
 * Servlet implementation class EmployeeEdit
 */
@WebServlet("/editDeduction")
public class DeductionEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public DeductionEditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String idStr = request.getParameter("id");
		if(idStr != null) {
			long id = Integer.parseInt(idStr);
			
			EmployeeDeductionDAO deductionDAO = new EmployeeDeductionDAO();
			EmployeeDeduction deduction = deductionDAO.getDeductionById(id);
		
			System.out.println(deduction);
			        request.setAttribute("deduction", deduction);
			        
              
	            request.getRequestDispatcher("editDeduction.jsp").forward(request, response);
			 }
			 }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 long id = Long.parseLong(request.getParameter("id"));
	        String deductionName = request.getParameter("deductionName");
	        String deductionValue = request.getParameter("deductionValue");
	        String deductioncalculationType = request.getParameter("deductioncalculationType");

	        try {
	           
	        	 EmployeeDeductionDAO deductionDAO=new EmployeeDeductionDAO();
	            EmployeeDeduction deduction = deductionDAO.getDeductionById(id);
	            deduction.setDeductionName(deductionName);
	            deduction.setDeductionValue(Double.parseDouble(deductionValue));
	            deduction.setCalculationType(deductioncalculationType);
	            deduction.setUpdatedDate(new Date());
	            System.out.println(deduction);
	            deductionDAO.updateDeduction(deduction);
	       
	        } catch (Exception e) {
	           
	            e.printStackTrace();
	        } 

	        response.sendRedirect("UpdateSuccessDeduction.jsp"); // Redirect to a success page
	    }
	}
	
